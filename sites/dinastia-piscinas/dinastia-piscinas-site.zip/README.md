# Dinastia Piscinas — Prévia Consecom

Site demonstrativo responsivo: construção, reforma, iluminação, revestimentos e planejador interativo.

## Instruções
Abra `index.html` no navegador ou publique o diretório em uma hospedagem estática.
Imagens da empresa em `assets/*.webp` ampliadas 4x a partir de recortes do perfil de Instagram enviado pelo contratante. Aumento conservador de resolução, sem invenção de elementos ou modificação dos textos. Os arquivos de baixa resolução estão preservados no diretório de desenvolvimento original, mas não são usados na versão publicada.

O planejador é ilustrativo e não representa projeto técnico, preço ou orçamento; o visitante deve copiar o resumo e abrir o WhatsApp divulgado no Instagram.

Foto de abertura e fonte tipográfica dependem de serviços externos; caso não carreguem, a imagem da galeria e fontes do sistema são usadas como fallback.

Proposta não oficial, sujeita à aprovação da empresa.
